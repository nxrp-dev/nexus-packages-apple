{
     File:       AE/AEUserTermTypes.h

     Contains:   AppleEvents AEUT resource format Interfaces.



     Copyright:  � 1991-2008 by Apple Computer, Inc., all rights reserved

     Bugs?:      For bug reports, consult the following page on
                 the World Wide Web:

                     http://bugs.freepascal.org

}
{
    Modified for use with Free Pascal
    Version 308
    Please report any bugs to <gpc@microbizz.nl>
}

{$ifc not defined MACOSALLINCLUDE or not MACOSALLINCLUDE}
{$mode macpas}
{$modeswitch cblocks}
{$packenum 1}
{$macro on}
{$inline on}
{$calling mwpascal}

{$IFNDEF FPC_DOTTEDUNITS}
unit AEUserTermTypes;
{$ENDIF FPC_DOTTEDUNITS}
interface
{$setc UNIVERSAL_INTERFACES_VERSION := $0400}
{$setc GAP_INTERFACES_VERSION := $0308}

{$ifc not defined USE_CFSTR_CONSTANT_MACROS}
    {$setc USE_CFSTR_CONSTANT_MACROS := TRUE}
{$endc}

{$ifc defined FPC_BIG_ENDIAN and defined FPC_LITTLE_ENDIAN}
	{$error Conflicting initial definitions for FPC_BIG_ENDIAN and FPC_LITTLE_ENDIAN}
{$endc}

	{$setc __i386__ := 0}
{$ifc not defined __x86_64__ and defined CPUX86_64}
	{$setc __x86_64__ := 1}
{$elsec}
	{$setc __x86_64__ := 0}
{$endc}
{$setc __arm__ := 0}
{$ifc not defined __arm64__ and defined CPUAARCH64}
  {$setc __arm64__ := 1}
{$elsec}
  {$setc __arm64__ := 0}
{$endc}

  {$setc __LP64__ := 1}



{$ifc defined __x86_64__ and __x86_64__}
	{$setc TARGET_CPU_X86 := FALSE}
	{$setc TARGET_CPU_X86_64 := TRUE}
	{$setc TARGET_CPU_ARM := FALSE}
	{$setc TARGET_CPU_ARM64 := FALSE}
{$ifc defined iphonesim}
 	{$setc TARGET_OS_MAC := FALSE}
	{$setc TARGET_OS_IPHONE := TRUE}
	{$setc TARGET_IPHONE_SIMULATOR := TRUE}
{$elsec}
	{$setc TARGET_OS_MAC := TRUE}
	{$setc TARGET_OS_IPHONE := FALSE}
	{$setc TARGET_IPHONE_SIMULATOR := FALSE}
{$endc}
	{$setc TARGET_OS_EMBEDDED := FALSE}
{$elifc defined __arm64__ and __arm64__}
	{$setc TARGET_CPU_X86 := FALSE}
	{$setc TARGET_CPU_X86_64 := FALSE}
	{$setc TARGET_CPU_ARM := FALSE}
	{$setc TARGET_CPU_ARM64 := TRUE}
{$ifc defined ios}
	{$setc TARGET_OS_MAC := FALSE}
	{$setc TARGET_OS_IPHONE := TRUE}
	{$setc TARGET_OS_EMBEDDED := TRUE}
{$elsec}
	{$setc TARGET_OS_MAC := TRUE}
	{$setc TARGET_OS_IPHONE := FALSE}
	{$setc TARGET_OS_EMBEDDED := FALSE}
{$endc}
	{$setc TARGET_IPHONE_SIMULATOR := FALSE}
{$elsec}
	{$error Neither __x86_64__ nor __arm64__ is defined.}
{$endc}

  {$setc TARGET_CPU_64 := TRUE}

{$ifc defined FPC_BIG_ENDIAN}
	{$setc TARGET_RT_BIG_ENDIAN := TRUE}
	{$setc TARGET_RT_LITTLE_ENDIAN := FALSE}
{$elifc defined FPC_LITTLE_ENDIAN}
	{$setc TARGET_RT_BIG_ENDIAN := FALSE}
	{$setc TARGET_RT_LITTLE_ENDIAN := TRUE}
{$elsec}
	{$error Neither FPC_BIG_ENDIAN nor FPC_LITTLE_ENDIAN are defined.}
{$endc}
{$setc ACCESSOR_CALLS_ARE_FUNCTIONS := TRUE}
{$setc CALL_NOT_IN_CARBON := FALSE}
{$setc OLDROUTINENAMES := FALSE}
{$setc OPAQUE_TOOLBOX_STRUCTS := TRUE}
{$setc OPAQUE_UPP_TYPES := TRUE}
{$setc OTCARBONAPPLICATION := TRUE}
{$setc OTKERNEL := FALSE}
{$setc PM_USE_SESSION_APIS := TRUE}
{$setc TARGET_API_MAC_CARBON := TRUE}
{$setc TARGET_API_MAC_OS8 := FALSE}
{$setc TARGET_API_MAC_OSX := TRUE}
{$setc TARGET_CARBON := TRUE}
{$setc TARGET_CPU_68K := FALSE}
{$setc TARGET_CPU_MIPS := FALSE}
{$setc TARGET_CPU_SPARC := FALSE}
{$setc TARGET_OS_UNIX := FALSE}
{$setc TARGET_OS_WIN32 := FALSE}
{$setc TARGET_RT_MAC_68881 := FALSE}
{$setc TARGET_RT_MAC_CFM := FALSE}
{$setc TARGET_RT_MAC_MACHO := TRUE}
{$setc TYPED_FUNCTION_POINTERS := TRUE}
{$setc TYPE_BOOL := FALSE}
{$setc TYPE_EXTENDED := FALSE}
{$setc TYPE_LONGLONG := TRUE}
{$IFDEF FPC_DOTTEDUNITS}
uses MacOsApi.MacTypes,MacOsApi.ConditionalMacros;
{$ELSE FPC_DOTTEDUNITS}
uses MacTypes,ConditionalMacros;
{$ENDIF FPC_DOTTEDUNITS}
{$endc} {not MACOSALLINCLUDE}


{$ifc TARGET_OS_MAC}

{$ALIGN MAC68K}

const
	kAEUserTerminology = FourCharCode('aeut'); {  0x61657574  }
	kAETerminologyExtension = FourCharCode('aete'); {  0x61657465  }
	kAEScriptingSizeResource = FourCharCode('scsz'); {  0x7363737a  }
	kAEOSAXSizeResource = FourCharCode('osiz');

const
	kAEUTHasReturningParam = 31;   { if event has a keyASReturning param }
	kAEUTOptional = 15;   { if something is optional }
	kAEUTlistOfItems = 14;   { if property or reply is a list. }
	kAEUTEnumerated = 13;   { if property or reply is of an enumerated type. }
	kAEUTReadWrite = 12;   { if property is writable. }
	kAEUTChangesState = 12;   { if an event changes state. }
	kAEUTTightBindingFunction = 12;   { if this is a tight-binding precedence function. }
                                        { AppleScript 1.3: new bits for reply, direct parameter, parameter, and property flags }
	kAEUTEnumsAreTypes = 11;   { if the enumeration is a list of types, not constants }
	kAEUTEnumListIsExclusive = 10;   { if the list of enumerations is a proper set }
	kAEUTReplyIsReference = 9;    { if the reply is a reference, not a value }
	kAEUTDirectParamIsReference = 9;    { if the direct parameter is a reference, not a value }
	kAEUTParamIsReference = 9;    { if the parameter is a reference, not a value }
	kAEUTPropertyIsReference = 9;    { if the property is a reference, not a value }
	kAEUTNotDirectParamIsTarget = 8;    { if the direct parameter is not the target of the event }
	kAEUTParamIsTarget = 8;    { if the parameter is the target of the event }
	kAEUTApostrophe = 3;    { if a term contains an apostrophe. }
	kAEUTFeminine = 2;    { if a term is feminine gender. }
	kAEUTMasculine = 1;    { if a term is masculine gender. }
	kAEUTPlural = 0;     { if a term is plural. }

type
	TScriptingSizeResourcePtr = ^TScriptingSizeResource;
	TScriptingSizeResource = record
		scriptingSizeFlags: SInt16;
		minStackSize: UInt32;
		preferredStackSize: UInt32;
		maxStackSize: UInt32;
		minHeapSize: UInt32;
		preferredHeapSize: UInt32;
		maxHeapSize: UInt32;
	end;
const
	kLaunchToGetTerminology = 1 shl 15; {    If kLaunchToGetTerminology is 0, 'aete' is read directly from res file.  If set to 1, then launch and use 'gdut' to get terminology. }
	kDontFindAppBySignature = 1 shl 14; {    If kDontFindAppBySignature is 0, then find app with signature if lost.  If 1, then don't }
	kAlwaysSendSubject = 1 shl 13; {    If kAlwaysSendSubject 0, then send subject when appropriate. If 1, then every event has Subject Attribute }

{ old names for above bits. }
const
	kReadExtensionTermsMask = 1 shl 15;

const
{ AppleScript 1.3: Bit positions for osiz resource }
                                        { AppleScript 1.3: Bit masks for osiz resources }
	kOSIZDontOpenResourceFile = 15;   { If set, resource file is not opened when osax is loaded }
	kOSIZdontAcceptRemoteEvents = 14;   { If set, handler will not be called with events from remote machines }
	kOSIZOpenWithReadPermission = 13;   { If set, file will be opened with read permission only }
	kOSIZCodeInSharedLibraries = 11;    { If set, loader will look for handler in shared library, not osax resources }


{$endc} {TARGET_OS_MAC}

{$ifc not defined MACOSALLINCLUDE or not MACOSALLINCLUDE}

end.
{$endc} {not MACOSALLINCLUDE}
